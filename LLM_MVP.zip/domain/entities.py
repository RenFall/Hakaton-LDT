from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Token:
    page_pdf: int
    bbox_abs: list[float]
    bbox_norm: list[float]
    text: str
    quote: str
    confidence: float
    method: str


@dataclass(frozen=True)
class Evidence:
    item: str
    file_id: str
    stage: str
    page_pdf: int
    sheet_no: str | None
    bbox: list[float]
    quote: str
    confidence: float
    method: str


@dataclass(frozen=True)
class ExtractedFact:
    room: str
    stage: str
    file_id: str
    value_norm: dict[str, Any]
    evidence: list[dict[str, Any]]
    confidence: float
    method: str
