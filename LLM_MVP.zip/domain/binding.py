from __future__ import annotations

from .entities import Token
from .system_rules import system_sort_key


def _center(token: Token) -> tuple[float, float]:
    x0, y0, x1, y1 = token.bbox_abs
    return ((x0 + x1) / 2, (y0 + y1) / 2)


def bind_systems_to_rooms(
    rooms: list[Token], systems: list[Token], max_distance: float = 150,
) -> dict[str, list[Token]]:
    """Provisional domain rule: bind only same-page tokens within the radius."""
    bound: dict[str, dict[tuple[str, int, tuple[float, ...]], Token]] = {}
    for room in rooms:
        room_x, room_y = _center(room)
        for system in systems:
            if system.page_pdf != room.page_pdf:
                continue
            system_x, system_y = _center(system)
            distance = ((room_x - system_x) ** 2 + (room_y - system_y) ** 2) ** 0.5
            if distance <= max_distance:
                key = (system.text, system.page_pdf, tuple(system.bbox_abs))
                bound.setdefault(room.text, {})[key] = system
    return {
        room: sorted(items.values(), key=lambda item: system_sort_key(item.text))
        for room, items in sorted(bound.items(), key=lambda item: int(item[0]))
    }
