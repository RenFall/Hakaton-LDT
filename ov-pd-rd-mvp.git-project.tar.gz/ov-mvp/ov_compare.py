#!/usr/bin/env python3
"""Minimal, local PD↔RD OV comparison with page and bbox evidence."""
from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import fitz  # PyMuPDF

SYSTEM_RE = re.compile(r"(?<![А-ЯA-Z0-9])([ВB])\s*(\d+)\s*[.,]\s*(\d+)(?!\d)", re.I)
OV_TARGET_ROOMS = {"140", "142", "147", "198", "314"}


@dataclass(frozen=True)
class Evidence:
    page: int
    bbox: list[float]
    text: str


@dataclass
class ExtractedFact:
    room: str
    pd_systems: list[str]
    rd_systems: list[str]
    missing: list[str]
    added: list[str]
    page_pd: int | None
    page_rd: int | None
    pd_evidence: list[dict[str, Any]]
    rd_evidence: list[dict[str, Any]]


def normalized_system(match: re.Match[str] | str) -> str:
    text = match.group(0) if hasattr(match, "group") else match
    found = SYSTEM_RE.search(text)
    if not found:
        raise ValueError(f"Not an OV system: {text!r}")
    return f"В{found.group(2)}.{found.group(3)}"


def _rect(rect: Any) -> list[float]:
    return [round(float(v), 2) for v in rect]


def _is_target_room(text: str) -> bool:
    """OV MVP deliberately operates only on the five annotated rooms."""
    return text in OV_TARGET_ROOMS


def _page_system_evidence(page: fitz.Page, page_no: int) -> list[Evidence]:
    """Find system labels in full page text, then retain only labels with PDF bbox."""
    found: dict[tuple[str, tuple[float, ...]], Evidence] = {}
    for match in SYSTEM_RE.finditer(page.get_text("text")):
        raw = match.group(0)
        system = normalized_system(match)
        for rect in page.search_for(raw):
            bbox = _rect(rect)
            found[(system, tuple(bbox))] = Evidence(page_no, bbox, system)
    return list(found.values())


def _center(evidence: Evidence) -> tuple[float, float] | None:
    if len(evidence.bbox) != 4:
        return None
    x0, y0, x1, y1 = evidence.bbox
    return ((x0 + x1) / 2, (y0 + y1) / 2)


def bind_systems_to_rooms(
    rooms: list[Evidence], systems: list[Evidence], max_distance: float = 150,
) -> dict[str, list[str]]:
    """Bind every system label to rooms on the same page within ``max_distance`` points.

    This deliberately simple heuristic is intended for an MVP.  It never binds across
    pages and silently ignores tokens without a usable bbox.  A system can belong to
    more than one nearby room; ambiguous assignments stay visible for review.
    """
    bound: dict[str, set[str]] = {}
    for room in rooms:
        room_center = _center(room)
        if room_center is None:
            continue
        for system in systems:
            system_center = _center(system)
            if system.page != room.page or system_center is None:
                continue
            distance = ((room_center[0] - system_center[0]) ** 2 +
                        (room_center[1] - system_center[1]) ** 2) ** 0.5
            if distance <= max_distance:
                bound.setdefault(room.text, set()).add(system.text)
    return {room: sorted(values) for room, values in sorted(bound.items(), key=lambda item: int(item[0]))}


def bound_evidence_by_room(
    rooms: list[Evidence], systems: list[Evidence], max_distance: float = 150,
) -> dict[str, list[Evidence]]:
    """Return the room label and every system evidence used in the binding."""
    result: dict[str, list[Evidence]] = {}
    for room in rooms:
        room_center = _center(room)
        if room_center is None:
            continue
        evidence = [room]
        for system in systems:
            system_center = _center(system)
            if system.page != room.page or system_center is None:
                continue
            if ((room_center[0] - system_center[0]) ** 2 +
                    (room_center[1] - system_center[1]) ** 2) ** 0.5 <= max_distance:
                evidence.append(system)
        if len(evidence) > 1:
            result.setdefault(room.text, []).extend(evidence)
    return result


def extract_pdf_tokens(pdf: str | Path) -> dict[str, list[Evidence]]:
    """Find room/system labels in a PDF without uploading its contents anywhere."""
    result: dict[str, list[Evidence]] = {"rooms": [], "systems": []}
    with fitz.open(pdf) as document:
        for page_no, page in enumerate(document, start=1):
            page_systems = _page_system_evidence(page, page_no)
            result["systems"].extend(page_systems)
            words = page.get_text("words")
            for x0, y0, x1, y1, text, *_ in words:
                evidence = Evidence(page_no, _rect((x0, y0, x1, y1)), text)
                if SYSTEM_RE.fullmatch(text):
                    system = Evidence(page_no, evidence.bbox, normalized_system(text))
                    if system not in result["systems"]:
                        result["systems"].append(system)
                elif _is_target_room(text):
                    result["rooms"].append(evidence)
    return result


def extract_document_layout(layout: dict[str, Any]) -> dict[str, list[Evidence]]:
    """Accept Azure DocumentLayout-like JSON: analyzeResult.pages[].words[]."""
    pages = layout.get("analyzeResult", layout).get("pages", [])
    result: dict[str, list[Evidence]] = {"rooms": [], "systems": []}
    for page_index, page in enumerate(pages, start=1):
        for word in page.get("words", []):
            text = str(word.get("content", ""))
            polygon = word.get("polygon") or word.get("boundingBox") or []
            if len(polygon) >= 4:
                xs, ys = polygon[::2], polygon[1::2]
                bbox = _rect((min(xs), min(ys), max(xs), max(ys)))
            else:
                bbox = []
            evidence = Evidence(int(page.get("pageNumber", page_index)), bbox, text)
            if SYSTEM_RE.fullmatch(text):
                result["systems"].append(Evidence(evidence.page, bbox, normalized_system(text)))
            elif _is_target_room(text):
                result["rooms"].append(evidence)
    return result


def compare(room: str, pd_systems: Iterable[str], rd_systems: Iterable[str], page_pd: int | None = None,
            page_rd: int | None = None, pd_evidence: Iterable[Evidence] = (),
            rd_evidence: Iterable[Evidence] = ()) -> ExtractedFact:
    pd = sorted({normalized_system(s) for s in pd_systems})
    rd = sorted({normalized_system(s) for s in rd_systems})
    return ExtractedFact(
        room=str(room), pd_systems=pd, rd_systems=rd,
        missing=sorted(set(pd) - set(rd)), added=sorted(set(rd) - set(pd)),
        page_pd=page_pd, page_rd=page_rd,
        pd_evidence=[asdict(item) for item in pd_evidence],
        rd_evidence=[asdict(item) for item in rd_evidence],
    )


def evidence_on_page(pdf: Path, page_no: int, needles: Iterable[str]) -> list[Evidence]:
    needles = set(needles)
    found: list[Evidence] = []
    with fitz.open(pdf) as document:
        page = document[page_no - 1]
        for needle in needles:
            for rect in page.search_for(needle):
                found.append(Evidence(page_no, _rect(rect), needle))
    return found


def run_fixtures(path: Path) -> list[ExtractedFact]:
    items = json.loads(path.read_text(encoding="utf-8"))
    facts: list[ExtractedFact] = []
    for item in items:
        pdf = (path.parent / item["evidence_pdf"]).resolve()
        pd_evidence = evidence_on_page(pdf, item["evidence_page"], [item["room"], *item["pd_systems"]])
        rd_evidence = evidence_on_page(pdf, item["evidence_page"], [item["room"], *item["rd_systems"]])
        facts.append(compare(item["room"], item["pd_systems"], item["rd_systems"],
                             item["page_pd"], item["page_rd"], pd_evidence, rd_evidence))
    return facts


def _evidence_map(raw: Any) -> dict[str, list[Evidence]]:
    return {
        room: [Evidence(**item) for item in entries]
        for room, entries in raw.get("room_evidence", {}).items()
    } if isinstance(raw, dict) else {}


def _system_map(raw: Any) -> dict[str, list[str]]:
    return raw.get("room_systems", raw) if isinstance(raw, dict) else raw


def write_json(facts: Any, output: str | None) -> None:
    text = json.dumps([asdict(f) for f in facts] if isinstance(facts, list) else facts,
                      ensure_ascii=False, indent=2)
    if output:
        Path(output).write_text(text + "\n", encoding="utf-8")
    else:
        print(text)


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    a = sub.add_parser("extract", help="Extract raw room/system tokens with PDF bbox")
    a.add_argument("pdf")
    a.add_argument("--layout", help="DocumentLayout JSON; used instead of PDF text")
    a.add_argument("--max-distance", type=float, default=150, help="Room/system binding radius in page units")
    a.add_argument("--output")
    c = sub.add_parser("compare", help="Compare two room → systems JSON maps")
    c.add_argument("--pd", required=True)
    c.add_argument("--rd", required=True)
    c.add_argument("--output")
    f = sub.add_parser("fixtures", help="Run annotated control cases with bbox evidence")
    f.add_argument("fixture_json")
    f.add_argument("--output")
    m = sub.add_parser("markitdown", help="Diagnostic text conversion only; no bbox")
    m.add_argument("pdf")
    m.add_argument("--output")
    args = parser.parse_args()

    if args.command == "extract":
        data = extract_document_layout(json.loads(Path(args.layout).read_text(encoding="utf-8"))) if args.layout else extract_pdf_tokens(args.pdf)
        write_json({
            **{key: [asdict(v) for v in values] for key, values in data.items()},
            "room_systems": bind_systems_to_rooms(data["rooms"], data["systems"], args.max_distance),
            "room_evidence": {key: [asdict(item) for item in value] for key, value in
                              bound_evidence_by_room(data["rooms"], data["systems"], args.max_distance).items()},
        }, args.output)
    elif args.command == "compare":
        pd_raw = json.loads(Path(args.pd).read_text(encoding="utf-8"))
        rd_raw = json.loads(Path(args.rd).read_text(encoding="utf-8"))
        pd, rd = _system_map(pd_raw), _system_map(rd_raw)
        pd_evidence, rd_evidence = _evidence_map(pd_raw), _evidence_map(rd_raw)
        facts = [compare(room, pd.get(room, []), rd.get(room, []),
                         next((item.page for item in pd_evidence.get(room, [])), None),
                         next((item.page for item in rd_evidence.get(room, [])), None),
                         pd_evidence.get(room, []), rd_evidence.get(room, []))
                 for room in sorted(set(pd) | set(rd), key=int)]
        write_json(facts, args.output)
    elif args.command == "fixtures":
        write_json(run_fixtures(Path(args.fixture_json)), args.output)
    else:
        from markitdown import MarkItDown
        text = MarkItDown().convert(args.pdf).text_content
        if args.output:
            Path(args.output).write_text(text, encoding="utf-8")
        else:
            print(text)


if __name__ == "__main__":
    main()
