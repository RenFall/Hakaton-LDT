from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ParameterValue:
    """An evidence-backed value emitted by a PD, RD, or ID connector."""
    object_id: str
    matrix_code: str
    stage: str
    value: Any
    evidence: list[dict[str, Any]]


@dataclass(frozen=True)
class ComparisonFinding:
    """A deterministic comparison result; confirmation remains a human action."""
    finding_id: str
    object_id: str
    matrix_code: str
    status: str
    expected: Any
    actual: Any
    evidence: list[dict[str, Any]]


def compare_parameter_values(baseline: ParameterValue, revised: ParameterValue) -> ComparisonFinding:
    """Compare a PD value against RD or ID evidence for the same matrix parameter."""
    if baseline.object_id != revised.object_id:
        raise ValueError("Cannot compare values from different objects")
    if baseline.matrix_code != revised.matrix_code:
        raise ValueError("Cannot compare different matrix parameters")
    if baseline.stage != "PD":
        raise ValueError("Baseline value must come from PD")
    if revised.stage not in {"RD", "ID"}:
        raise ValueError("Revised value must come from RD or ID")
    status = "NEGATIVE_VERIFIED" if baseline.value == revised.value else "CANDIDATE"
    return ComparisonFinding(
        finding_id=f"{baseline.object_id}:{baseline.matrix_code}:{revised.stage}",
        object_id=baseline.object_id,
        matrix_code=baseline.matrix_code,
        status=status,
        expected=baseline.value,
        actual=revised.value,
        evidence=[*baseline.evidence, *revised.evidence],
    )
