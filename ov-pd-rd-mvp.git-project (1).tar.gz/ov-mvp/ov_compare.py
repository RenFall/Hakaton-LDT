#!/usr/bin/env python3
"""Extract room-to-OV-system facts from real PD/RD drawings.

Gold/annotation PDFs are validation inputs and are deliberately rejected.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import fitz

SYSTEM_RE = re.compile(r"(?<![А-ЯA-Z0-9])([ВB])\s*(\d+)\s*[.,]\s*(\d+)(?!\d)", re.I)
SYSTEM_RANGE_RE = re.compile(
    r"(?<![А-ЯA-Z0-9])([ВB])\s*(\d+)\s*[.,]\s*(\d+)\s*[-–—]\s*"
    r"(?:[ВB]\s*)?(?:(\d+)\s*[.,]\s*)?(\d+)(?!\d)", re.I,
)
OV_TARGET_ROOMS = {"140", "142", "147", "198", "314"}
ANNOTATION_MARKERS = (
    "комплект предметной разметки",
    "нарушение 3. помещения",
    "состав комплекта",
)


class AnnotationInputError(ValueError):
    """Raised when a gold/annotation document is passed as an extraction source."""


@dataclass(frozen=True)
class Token:
    page_pdf: int
    bbox_abs: list[float]
    bbox_norm: list[float]
    text: str
    quote: str
    confidence: float
    method: str


@dataclass(frozen=True)
class Evidence:
    item: str
    file_id: str
    stage: str
    page_pdf: int
    sheet_no: str | None
    bbox: list[float]
    quote: str
    confidence: float
    method: str


@dataclass(frozen=True)
class ExtractedFact:
    room: str
    stage: str
    file_id: str
    value_norm: dict[str, Any]
    evidence: list[dict[str, Any]]
    confidence: float
    method: str


def system_sort_key(value: str) -> tuple[int, int]:
    match = SYSTEM_RE.fullmatch(value)
    if not match:
        return (10**9, 10**9)
    return (int(match.group(2)), int(match.group(3)))


def normalized_system(value: re.Match[str] | str) -> str:
    text = value.group(0) if hasattr(value, "group") else value
    match = SYSTEM_RE.search(text)
    if not match:
        raise ValueError(f"Not an OV system: {text!r}")
    return f"В{int(match.group(2))}.{int(match.group(3))}"


def expand_system_expression(text: str) -> list[str]:
    """Expand В2.2-В2.4 while retaining the full range as shared evidence."""
    range_match = SYSTEM_RANGE_RE.fullmatch(text.strip().rstrip(";,"))
    if not range_match:
        match = SYSTEM_RE.search(text)
        return [normalized_system(match)] if match else []
    major_start = int(range_match.group(2))
    minor_start = int(range_match.group(3))
    major_end = int(range_match.group(4) or major_start)
    minor_end = int(range_match.group(5))
    if major_start != major_end or minor_end < minor_start or minor_end - minor_start > 50:
        return []
    return [f"В{major_start}.{minor}" for minor in range(minor_start, minor_end + 1)]


def _round_rect(rect: Iterable[float]) -> list[float]:
    return [round(float(value), 4) for value in rect]


def normalize_bbox(page: fitz.Page, rect: fitz.Rect) -> list[float]:
    """Normalize an unrotated PDF bbox to [0,1], accounting for CropBox and Rotate."""
    crop = page.cropbox
    relative = fitz.Rect(rect.x0 - crop.x0, rect.y0 - crop.y0,
                         rect.x1 - crop.x0, rect.y1 - crop.y0)
    if page.rotation:
        relative = relative * page.rotation_matrix
        width, height = page.rect.width, page.rect.height
    else:
        width, height = crop.width, crop.height
    if width <= 0 or height <= 0:
        raise ValueError("PDF page has an invalid CropBox")
    values = [relative.x0 / width, relative.y0 / height,
              relative.x1 / width, relative.y1 / height]
    return [round(min(1.0, max(0.0, value)), 6) for value in values]


def document_file_id(path: Path) -> str:
    digest = hashlib.sha256(path.read_bytes()).hexdigest()[:16]
    return f"sha256:{digest}"


def reject_annotation_pdf(document: fitz.Document) -> None:
    sample = "\n".join(page.get_text("text") for page in list(document)[:6]).lower()
    marker = next((item for item in ANNOTATION_MARKERS if item in sample), None)
    if marker:
        raise AnnotationInputError(
            f"Annotation/gold PDF rejected (marker: {marker!r}). "
            "Use only original PD or RD drawings as extractor input."
        )


def _center(token: Token) -> tuple[float, float]:
    x0, y0, x1, y1 = token.bbox_abs
    return ((x0 + x1) / 2, (y0 + y1) / 2)


def _system_tokens(page: fitz.Page, page_no: int) -> list[Token]:
    page_text = page.get_text("text")
    range_matches = list(SYSTEM_RANGE_RE.finditer(page_text))
    expressions = [match.group(0) for match in range_matches]
    range_spans = [match.span() for match in range_matches]
    for match in SYSTEM_RE.finditer(page_text):
        if not any(start <= match.start() and match.end() <= end for start, end in range_spans):
            expressions.append(match.group(0))

    tokens: dict[tuple[str, tuple[float, ...]], Token] = {}
    for expression in expressions:
        items = expand_system_expression(expression)
        for rect in page.search_for(expression):
            bbox_abs = _round_rect(rect)
            for item in items:
                token = Token(page_no, bbox_abs, normalize_bbox(page, rect), item,
                              expression, 0.75, "pdf_text_regex")
                tokens[(item, tuple(bbox_abs))] = token
    return list(tokens.values())


def extract_pdf_tokens(pdf: str | Path) -> dict[str, list[Token]]:
    path = Path(pdf)
    result: dict[str, list[Token]] = {"rooms": [], "systems": []}
    with fitz.open(path) as document:
        reject_annotation_pdf(document)
        for page_no, page in enumerate(document, start=1):
            result["systems"].extend(_system_tokens(page, page_no))
            for x0, y0, x1, y1, text, *_ in page.get_text("words"):
                if text not in OV_TARGET_ROOMS:
                    continue
                rect = fitz.Rect(x0, y0, x1, y1)
                result["rooms"].append(Token(
                    page_no, _round_rect(rect), normalize_bbox(page, rect), text,
                    text, 0.95, "pdf_text_target_room",
                ))
    return result


def bind_systems_to_rooms(
    rooms: list[Token], systems: list[Token], max_distance: float = 150,
) -> dict[str, list[Token]]:
    """Provisional same-page nearest-bbox binding for the five MVP rooms."""
    bound: dict[str, dict[tuple[str, int, tuple[float, ...]], Token]] = {}
    for room in rooms:
        room_x, room_y = _center(room)
        for system in systems:
            if system.page_pdf != room.page_pdf:
                continue
            system_x, system_y = _center(system)
            distance = ((room_x - system_x) ** 2 + (room_y - system_y) ** 2) ** 0.5
            if distance <= max_distance:
                key = (system.text, system.page_pdf, tuple(system.bbox_abs))
                bound.setdefault(room.text, {})[key] = system
    return {room: sorted(items.values(), key=lambda item: system_sort_key(item.text))
            for room, items in sorted(bound.items(), key=lambda item: int(item[0]))}


def build_facts(
    bound: dict[str, list[Token]], *, file_id: str, stage: str, sheet_no: str | None,
) -> list[ExtractedFact]:
    facts: list[ExtractedFact] = []
    for room, tokens in bound.items():
        systems = sorted({token.text for token in tokens}, key=system_sort_key)
        evidence = [Evidence(
            item=token.text, file_id=file_id, stage=stage,
            page_pdf=token.page_pdf, sheet_no=sheet_no,
            bbox=token.bbox_norm, quote=token.quote,
            confidence=token.confidence, method=token.method,
        ) for token in tokens]
        facts.append(ExtractedFact(
            room=room, stage=stage, file_id=file_id,
            value_norm={"kind": "set", "items": systems},
            evidence=[asdict(item) for item in evidence],
            confidence=min((item.confidence for item in evidence), default=0.0),
            method="nearest_bbox_same_page",
        ))
    return facts


def write_json(value: Any, output: str | None) -> None:
    payload = [asdict(item) if hasattr(item, "__dataclass_fields__") else item for item in value]
    text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if output:
        Path(output).write_text(text, encoding="utf-8")
    else:
        print(text, end="")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf", help="Original PD or RD PDF; annotation PDFs are rejected")
    parser.add_argument("--stage", required=True, choices=("PD", "RD"))
    parser.add_argument("--file-id", help="Stable source id; defaults to a SHA-256 based id")
    parser.add_argument("--sheet-no", help="Sheet number from the drawing title block")
    parser.add_argument("--max-distance", type=float, default=150)
    parser.add_argument("--output")
    args = parser.parse_args()

    path = Path(args.pdf)
    file_id = args.file_id or document_file_id(path)
    try:
        tokens = extract_pdf_tokens(path)
    except AnnotationInputError as error:
        parser.error(str(error))
    bound = bind_systems_to_rooms(tokens["rooms"], tokens["systems"], args.max_distance)
    write_json(build_facts(bound, file_id=file_id, stage=args.stage, sheet_no=args.sheet_no), args.output)


if __name__ == "__main__":
    main()
