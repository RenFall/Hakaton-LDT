from __future__ import annotations

from pathlib import Path
from typing import Protocol

import fitz

from domain.entities import Token
from domain.system_rules import expand_system_expression


class EvidenceLocator(Protocol):
    def locate(
        self, pdf: str | Path, rooms: list[str], system_expressions: list[str],
    ) -> dict[str, list[Token]]: ...


def _round_rect(rect) -> list[float]:
    return [round(float(value), 4) for value in rect]


def normalize_bbox(page: fitz.Page, rect: fitz.Rect) -> list[float]:
    crop = page.cropbox
    relative = fitz.Rect(rect.x0 - crop.x0, rect.y0 - crop.y0,
                         rect.x1 - crop.x0, rect.y1 - crop.y0)
    if page.rotation:
        relative = relative * page.rotation_matrix
        width, height = page.rect.width, page.rect.height
    else:
        width, height = crop.width, crop.height
    if width <= 0 or height <= 0:
        raise ValueError("PDF page has an invalid CropBox")
    values = [relative.x0 / width, relative.y0 / height,
              relative.x1 / width, relative.y1 / height]
    return [round(min(1.0, max(0.0, value)), 6) for value in values]


class PyMuPDFEvidenceLocator:
    """Coordinate adapter only; it does not decide which text is meaningful."""

    def locate(
        self, pdf: str | Path, rooms: list[str], system_expressions: list[str],
    ) -> dict[str, list[Token]]:
        result: dict[str, list[Token]] = {"rooms": [], "systems": []}
        seen_systems: set[tuple[str, int, tuple[float, ...]]] = set()
        seen_rooms: set[tuple[str, int, tuple[float, ...]]] = set()
        with fitz.open(Path(pdf)) as document:
            for page_no, page in enumerate(document, start=1):
                for expression in system_expressions:
                    for rect in page.search_for(expression):
                        bbox_abs = _round_rect(rect)
                        for item in expand_system_expression(expression):
                            key = (item, page_no, tuple(bbox_abs))
                            if key in seen_systems:
                                continue
                            seen_systems.add(key)
                            result["systems"].append(Token(
                                page_no, bbox_abs, normalize_bbox(page, rect), item,
                                expression, 0.75, "markitdown+pymupdf_bbox",
                            ))
                for room in rooms:
                    for rect in page.search_for(room):
                        bbox_abs = _round_rect(rect)
                        key = (room, page_no, tuple(bbox_abs))
                        if key in seen_rooms:
                            continue
                        seen_rooms.add(key)
                        result["rooms"].append(Token(
                            page_no, bbox_abs, normalize_bbox(page, rect), room,
                            room, 0.95, "target_room+pymupdf_bbox",
                        ))
        return result


class DocumentLayoutEvidenceLocator:
    """Placeholder for the participant-4 DocumentLayout bbox adapter."""

    def locate(
        self, pdf: str | Path, rooms: list[str], system_expressions: list[str],
    ) -> dict[str, list[Token]]:
        raise NotImplementedError("DocumentLayoutEvidenceLocator requires the agreed JSON contract")
