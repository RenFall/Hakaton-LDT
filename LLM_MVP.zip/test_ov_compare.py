import unittest
import json
from pathlib import Path
from unittest.mock import patch

import fitz

from domain.binding import bind_systems_to_rooms
from domain.entities import ExtractedFact, Token
from domain.system_rules import expand_system_expression, system_sort_key
from services.evidence_locator import normalize_bbox
from services.fact_service import FactExtractionService, build_facts
from services.llm import LLMNotConfigured, OpenAILikeConfig
from services.markitdown_extractor import (
    AnnotationInputError,
    MarkItDownDrawingExtractor,
    reject_annotation_text,
)
from services.parameter_compare import ParameterValue, compare_parameter_values
from services.ov_comparison import compare_ov_configurations


class OvCompareTests(unittest.TestCase):
    def test_bbox_is_normalized_for_rotated_page(self):
        document = fitz.open()
        page = document.new_page(width=200, height=100)
        page.set_rotation(90)
        bbox = normalize_bbox(page, fitz.Rect(20, 10, 40, 30))
        self.assertTrue(all(0 <= value <= 1 for value in bbox))
        self.assertLess(bbox[0], bbox[2])
        self.assertLess(bbox[1], bbox[3])

    def test_annotation_document_is_rejected(self):
        with self.assertRaises(AnnotationInputError):
            reject_annotation_text("Состав комплекта предметной разметки")

    def test_markitdown_is_semantic_source(self):
        class Result:
            text_content = "Помещение 140. Системы В2.8-В2.10"

        class Converter:
            @staticmethod
            def convert(_path):
                return Result()

        class Locator:
            rooms = []
            expressions = []

            def locate(self, _pdf, rooms, expressions):
                self.rooms = rooms
                self.expressions = expressions
                return {"rooms": [], "systems": []}

        locator = Locator()
        MarkItDownDrawingExtractor(locator, Converter()).extract_tokens("drawing.pdf")
        self.assertEqual(locator.rooms, ["140"])
        self.assertEqual(locator.expressions, ["В2.8-В2.10"])

    def test_llm_config_is_disabled_without_environment(self):
        with patch.dict("os.environ", {}, clear=True):
            with self.assertRaises(LLMNotConfigured):
                OpenAILikeConfig.from_env()

    def test_llm_audit_preserves_evidence_backed_facts(self):
        class Extractor:
            @staticmethod
            def extract_tokens(_pdf):
                return {
                    "rooms": [Token(1, [0, 0, 10, 10], [0, 0, .1, .1], "140", "140", .95, "test")],
                    "systems": [Token(1, [20, 0, 30, 10], [.2, 0, .3, .1], "В2.8", "В2.8", .75, "test")],
                }

        class LLM:
            def complete_json(self, *, system_prompt, user_prompt):
                self.system_prompt = system_prompt
                self.user_prompt = user_prompt
                return {"status": "ok", "issues": []}

        llm = LLM()
        facts, audit = FactExtractionService(Extractor(), max_distance=50).extract_with_llm_audit(
            "drawing.pdf", file_id="PD-1", stage="PD", sheet_no="1", llm_client=llm,
        )
        self.assertEqual(audit, {"status": "ok", "issues": []})
        self.assertEqual(facts[0].evidence[0]["item"], "В2.8")
        self.assertIn('"item": "В2.8"', llm.user_prompt)

    def test_real_scenario_comparison_is_candidate_or_negative_control(self):
        pd = ParameterValue("SOSH25", "M-002", "PD", 6234.1, [{"stage": "PD", "page_pdf": 49}])
        rd = ParameterValue("SOSH25", "M-002", "RD", 6252.3, [{"stage": "RD", "page_pdf": 34}])
        finding = compare_parameter_values(pd, rd)
        self.assertEqual(finding.status, "CANDIDATE")
        self.assertEqual(finding.finding_id, "SOSH25:M-002:RD")
        self.assertEqual(len(finding.evidence), 2)
        self.assertEqual(compare_parameter_values(pd, ParameterValue(
            "SOSH25", "M-002", "RD", 6234.1, [{"stage": "RD", "page_pdf": 34}],
        )).status, "NEGATIVE_VERIFIED")

    def test_explanatory_markup_gold_cases_are_ov_candidates(self):
        gold = json.loads((Path(__file__).parent / "fixtures" / "gold_expected.json").read_text(encoding="utf-8"))
        pd_facts = [ExtractedFact(
            room=item["room"], stage="PD", file_id="АНО/150321/1-П-ИОС5.4.2",
            value_norm={"kind": "set", "items": item["pd"]},
            evidence=[{"stage": "PD", "page_pdf": 10, "room": item["room"]}],
            confidence=.75, method="test",
        ) for item in gold]
        findings = compare_ov_configurations(pd_facts, [])
        self.assertEqual([item.object_id for item in findings], [item["room"] for item in gold])
        self.assertTrue(all(item.status == "CANDIDATE" and item.actual == [] for item in findings))

    def test_range_uses_natural_order(self):
        systems = expand_system_expression("В2.8-В2.10")
        self.assertEqual(systems, ["В2.8", "В2.9", "В2.10"])
        self.assertEqual(sorted(systems, key=system_sort_key), systems)

    def test_binding_does_not_cross_pages(self):
        rooms = [Token(1, [0, 0, 10, 10], [0, 0, .1, .1], "140", "140", .95, "test")]
        systems = [
            Token(1, [20, 0, 30, 10], [.2, 0, .3, .1], "В2.7", "В2.7-В2.9", .75, "test"),
            Token(2, [20, 0, 30, 10], [.2, 0, .3, .1], "В2.8", "В2.7-В2.9", .75, "test"),
        ]
        bound = bind_systems_to_rooms(rooms, systems, max_distance=50)
        self.assertEqual([item.text for item in bound["140"]], ["В2.7"])

    def test_fact_has_per_item_source_evidence(self):
        tokens = [
            Token(10, [10, 10, 20, 20], [.1, .1, .2, .2], value, "В2.8-В2.10", .75, "test")
            for value in ("В2.8", "В2.9", "В2.10")
        ]
        fact = build_facts({"198": tokens}, file_id="PD-1", stage="PD", sheet_no="10")[0]
        self.assertEqual(fact.value_norm, {"kind": "set", "items": ["В2.8", "В2.9", "В2.10"]})
        self.assertEqual({item["item"] for item in fact.evidence}, {"В2.8", "В2.9", "В2.10"})
        self.assertTrue(all(item["file_id"] == "PD-1" and item["stage"] == "PD" for item in fact.evidence))


if __name__ == "__main__":
    unittest.main()
