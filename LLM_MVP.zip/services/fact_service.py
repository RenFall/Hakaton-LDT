from __future__ import annotations

import json
from dataclasses import asdict
from typing import Any

from domain.binding import bind_systems_to_rooms
from domain.entities import Evidence, ExtractedFact, Token
from domain.system_rules import system_sort_key
from .llm import LLMClient


LLM_AUDIT_SYSTEM_PROMPT = (
    "You audit extracted PDF facts. Return only a JSON object with keys "
    "status (ok or review) and issues (an array of strings). Do not invent facts "
    "or evidence; the supplied facts remain authoritative."
)


def build_facts(
    bound: dict[str, list[Token]], *, file_id: str, stage: str, sheet_no: str | None,
) -> list[ExtractedFact]:
    facts: list[ExtractedFact] = []
    for room, tokens in bound.items():
        systems = sorted({token.text for token in tokens}, key=system_sort_key)
        evidence = [Evidence(
            item=token.text, file_id=file_id, stage=stage,
            page_pdf=token.page_pdf, sheet_no=sheet_no,
            bbox=token.bbox_norm, quote=token.quote,
            confidence=token.confidence, method=token.method,
        ) for token in tokens]
        facts.append(ExtractedFact(
            room=room, stage=stage, file_id=file_id,
            value_norm={"kind": "set", "items": systems},
            evidence=[asdict(item) for item in evidence],
            confidence=min((item.confidence for item in evidence), default=0.0),
            method="nearest_bbox_same_page",
        ))
    return facts


class FactExtractionService:
    """Application service orchestrating extraction, binding and fact construction."""

    def __init__(self, extractor, *, max_distance: float = 150):
        self.extractor = extractor
        self.max_distance = max_distance

    def extract(self, pdf, *, file_id: str, stage: str, sheet_no: str | None) -> list[ExtractedFact]:
        tokens = self.extractor.extract_tokens(pdf)
        bound = bind_systems_to_rooms(tokens["rooms"], tokens["systems"], self.max_distance)
        return build_facts(bound, file_id=file_id, stage=stage, sheet_no=sheet_no)

    def extract_with_llm_audit(
        self, pdf, *, file_id: str, stage: str, sheet_no: str | None, llm_client: LLMClient,
    ) -> tuple[list[ExtractedFact], dict[str, Any]]:
        """Extract evidence-backed facts, then ask an LLM to audit without changing them."""
        facts = self.extract(pdf, file_id=file_id, stage=stage, sheet_no=sheet_no)
        audit = llm_client.complete_json(
            system_prompt=LLM_AUDIT_SYSTEM_PROMPT,
            user_prompt=json.dumps([asdict(fact) for fact in facts], ensure_ascii=False),
        )
        return facts, audit
