# OV facts extractor MVP

## Quick Start

В PowerShell из корня проекта создайте окружение и установите зависимости через `uv`:

```powershell
uv venv .venv
uv pip install --python .venv\Scripts\python.exe -r requirements.txt
.\.venv\Scripts\python.exe -m unittest -v
```

Извлечение фактов из одного исходного PDF:

```powershell
.\.venv\Scripts\python.exe ov_compare.py pd.pdf `
  --stage PD `
  --file-id 'ANO/150321/1-P-IOS5.4.2' `
  --sheet-no 10 `
  --output pd-facts.json
```

Сравнение независимых исходных версий ПД и РД:

```powershell
.\.venv\Scripts\python.exe ov_compare.py pd.pdf `
  --stage PD `
  --compare-with rd.pdf `
  --output comparison.json
```

## Как работает pipeline

1. MarkItDown извлекает текст из исходного PDF.
2. Pipeline находит поддерживаемые помещения и системы `В2.x`/`В3.x`.
3. PyMuPDF добавляет страницу, цитату и нормализованный bbox каждого найденного элемента.
4. Системы связываются с помещением только на той же странице и в пределах `--max-distance` (по умолчанию `150`).
5. При `--compare-with` факты ПД и РД сравниваются по помещению. Изменение или отсутствие решения в РД создаёт `CANDIDATE` с evidence обеих стадий.

Обычный вывод — массив фактов. С `--compare-with` вывод содержит `facts`, `comparison.rd_facts` и `comparison.findings`.

## LLM-аудит

LLM не создаёт и не исправляет факты: флаг `--llm-audit` передаёт ему только уже извлечённые evidence-backed факты и добавляет поле `llm_audit` в выходной JSON.

```powershell
$env:LLM_BASE_URL = 'https://tokenharbor.ai/v1'
$env:LLM_MODEL = 'mimo-v2.6-flash:free'
$env:LLM_API_KEY = '<ключ>'

.\.venv\Scripts\python.exe ov_compare.py pd.pdf --stage PD --llm-audit --output pd-audited.json
```

## GOLD и ограничения

`ТЗ/Комплект_предметной_разметки.pdf` и файл с пояснениями — GOLD-эталон, не вход pipeline и не источник для LLM. `fixtures/gold_expected.json` используется acceptance-тестом для пяти ОВ-кейсов: `140`, `142`, `147`, `198`, `314`.

Автоматизация выдаёт только `CANDIDATE`; `CONFIRMED_VIOLATION` подтверждает эксперт. Поддерживаемая область MVP: указанные пять помещений и системы `В2.x`/`В3.x`.

Минимальный extractor фактов «помещение → множество систем» из **исходных** PDF ПД или РД.
Файл предметной разметки используется только как gold для проверки и отклоняется как вход.

## Архитектура

Код разделён на слои DDD:

```text
domain/
  entities.py       Token, Evidence, ExtractedFact
  system_rules.py   нормализация, диапазоны и естественная сортировка
  binding.py        правило room → systems
services/
  markitdown_extractor.py  основной текстовый/семантический extractor
  evidence_locator.py      адаптеры координат PyMuPDF и DocumentLayout
  fact_service.py          orchestration use case
  llm.py                   заглушка OpenAI-compatible API
  cli.py                   командная строка
```

`MarkItDown` — единственный источник текста, из которого выбираются помещения и системы.
`PyMuPDF` не извлекает смысловые сущности: он только находит bbox уже выбранной строки в
исходном PDF и нормализует координаты с учётом CropBox/Rotate. Адаптер `DocumentLayout`
оставлен как явная точка расширения до согласования его JSON-контракта.

## Граница MVP

- целевые помещения: `140`, `142`, `147`, `198`, `314`;
- системы: `В2.x`, `В3.x`, включая диапазоны `В2.8-В2.10`;
- один выходной факт на пару `помещение × стадия`;
- bbox нормализован в `[0;1]` с учётом CropBox и Rotate;
- у каждого элемента множества своё evidence с `file_id`, `stage`, страницей, листом, quote,
  confidence и method;
- Python не вычисляет `missing/added`: сравнение множеств выполняет внешний движок.

Привязка `nearest_bbox_same_page` пока является упрощённой гипотезой. Она должна быть заменена
на привязку по контуру помещения или концу выноски, когда появятся исходные листы и разметка зон.

## Установка и тесты

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m unittest -v
```

## Запуск

```bash
python ov_compare.py pd.pdf \
  --stage PD \
  --file-id 'АНО/150321/1-П-ИОС5.4.2' \
  --sheet-no 10 \
  --output pd-facts.json

python ov_compare.py rd-ov1.pdf \
  --stage RD \
  --file-id 'ОВ1' \
  --sheet-no 4 \
  --output rd-facts.json
```

Если передать «Комплект предметной разметки», команда завершится ошибкой. Это защита от
повторного чтения ответа вместо исходных чертежей.

## Необязательный LLM-аудит

`services/llm.py` содержит минимальный клиент `/chat/completions` для OpenAI-compatible API.
Он выключен по умолчанию и настраивается переменными:

```bash
export LLM_BASE_URL='https://llm.example/v1'
export LLM_MODEL='model-name'
export LLM_API_KEY='optional-token'
```

Флаг `--llm-audit` запускает LLM после извлечения доказательных фактов. Он возвращает
`{"facts": [...], "llm_audit": {...}}`, но не может создавать или изменять факты и их
`page + bbox` evidence.

```bash
python ov_compare.py pd.pdf --stage PD --llm-audit --output pd-facts-audited.json
```

Для сравнения независимых исходных листов передайте ПД как первый файл, а РД через
`--compare-with`. Результат содержит факты обеих стадий и `comparison.findings`; разметочный
комплект применяется только как GOLD-оракул, а не как входной файл.

```bash
python ov_compare.py pd.pdf --stage PD --compare-with rd.pdf --output comparison.json
```

## Нужные исходные документы

- ПД `АНО/150321/1-П-ИОС5.4.2`: листы 10, 21 и 26;
- РД `ОВ1`: листы 3, 4 и 6;
- РД `ОВ2.1`: лист 4.

Без этих PDF нельзя заявлять точность или воспроизведение нарушений заказчика.

## Приёмка следующей версии

1. Вход — только исходные PDF ПД и РД.
2. Совпадают помещение и тип расхождения с gold.
3. Каждое evidence указывает на исходный `file_id` и страницу ПД/РД.
4. IoU bbox с вручную перенесёнными зонами gold не меньше `0.5`.

Текущий статус и результаты unit-тестов находятся в `tests/test_results.md`.
