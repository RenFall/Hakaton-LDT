from __future__ import annotations

import re

SYSTEM_RE = re.compile(r"(?<![А-ЯA-Z0-9])([ВB])\s*(\d+)\s*[.,]\s*(\d+)(?!\d)", re.I)
SYSTEM_RANGE_RE = re.compile(
    r"(?<![А-ЯA-Z0-9])([ВB])\s*(\d+)\s*[.,]\s*(\d+)\s*[-–—]\s*"
    r"(?:[ВB]\s*)?(?:(\d+)\s*[.,]\s*)?(\d+)(?!\d)", re.I,
)
OV_TARGET_ROOMS = {"140", "142", "147", "198", "314"}


def system_sort_key(value: str) -> tuple[int, int]:
    match = SYSTEM_RE.fullmatch(value)
    if not match:
        return (10**9, 10**9)
    return (int(match.group(2)), int(match.group(3)))


def normalized_system(value: re.Match[str] | str) -> str:
    text = value.group(0) if hasattr(value, "group") else value
    match = SYSTEM_RE.search(text)
    if not match:
        raise ValueError(f"Not an OV system: {text!r}")
    return f"В{int(match.group(2))}.{int(match.group(3))}"


def expand_system_expression(text: str) -> list[str]:
    range_match = SYSTEM_RANGE_RE.fullmatch(text.strip().rstrip(";,"))
    if not range_match:
        match = SYSTEM_RE.search(text)
        return [normalized_system(match)] if match else []
    major_start = int(range_match.group(2))
    minor_start = int(range_match.group(3))
    major_end = int(range_match.group(4) or major_start)
    minor_end = int(range_match.group(5))
    if major_start != major_end or minor_end < minor_start or minor_end - minor_start > 50:
        return []
    return [f"В{major_start}.{minor}" for minor in range(minor_start, minor_end + 1)]
