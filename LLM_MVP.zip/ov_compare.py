#!/usr/bin/env python3
"""Compatibility entry point for the OV facts extractor."""

from services.cli import main


if __name__ == "__main__":
    main()
