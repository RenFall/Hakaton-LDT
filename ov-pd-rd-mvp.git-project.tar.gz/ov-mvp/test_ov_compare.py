import unittest
from pathlib import Path

from ov_compare import compare, run_fixtures


class OvCompareTests(unittest.TestCase):
    def test_difference_is_bidirectional(self):
        fact = compare("147", ["В2.10"], ["В2.2", "В2.3", "В2.4"])
        self.assertEqual(fact.missing, ["В2.10"])
        self.assertEqual(fact.added, ["В2.2", "В2.3", "В2.4"])

    def test_annotated_cases_have_split_page_evidence(self):
        facts = run_fixtures(Path("fixtures/ov_annotated_cases.json"))
        self.assertEqual({fact.room for fact in facts}, {"140", "142", "147", "198", "314"})
        self.assertTrue(all(fact.page_pd and fact.page_rd and fact.pd_evidence and fact.rd_evidence for fact in facts))
        self.assertEqual(next(f for f in facts if f.room == "140").missing, ["В2.7", "В2.8", "В2.9"])


if __name__ == "__main__":
    unittest.main()
