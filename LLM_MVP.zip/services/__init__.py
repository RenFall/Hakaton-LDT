"""Application and infrastructure services for OV extraction."""
