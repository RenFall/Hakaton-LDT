from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

from .evidence_locator import PyMuPDFEvidenceLocator
from .fact_service import FactExtractionService
from .llm import OpenAILikeClient, OpenAILikeConfig
from .markitdown_extractor import AnnotationInputError, MarkItDownDrawingExtractor, document_file_id
from .ov_comparison import compare_ov_configurations


def _write_json(items, output: str | None, *, llm_audit=None, comparison=None) -> None:
    facts = [asdict(item) for item in items]
    if llm_audit is None and comparison is None:
        payload = facts
    else:
        payload = {"facts": facts}
        if llm_audit is not None:
            payload["llm_audit"] = llm_audit
        if comparison is not None:
            payload["comparison"] = comparison
    text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if output:
        Path(output).write_text(text, encoding="utf-8")
    else:
        print(text, end="")


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract OV facts from original PD/RD PDFs")
    parser.add_argument("pdf")
    parser.add_argument("--stage", required=True, choices=("PD", "RD"))
    parser.add_argument("--file-id")
    parser.add_argument("--sheet-no")
    parser.add_argument("--max-distance", type=float, default=150)
    parser.add_argument("--output")
    parser.add_argument("--llm-audit", action="store_true", help="Audit extracted facts through LLM")
    parser.add_argument("--compare-with", help="Independent RD PDF to compare with the PD input")
    args = parser.parse_args()

    path = Path(args.pdf)
    extractor = MarkItDownDrawingExtractor(PyMuPDFEvidenceLocator())
    service = FactExtractionService(extractor, max_distance=args.max_distance)
    try:
        options = {
            "file_id": args.file_id or document_file_id(path),
            "stage": args.stage,
            "sheet_no": args.sheet_no,
        }
        if args.llm_audit:
            facts, audit = service.extract_with_llm_audit(
                path, llm_client=OpenAILikeClient(OpenAILikeConfig.from_env()), **options,
            )
        else:
            facts = service.extract(path, **options)
            audit = None
        comparison = None
        if args.compare_with:
            if args.stage != "PD":
                parser.error("--compare-with requires --stage PD for the baseline file")
            rd_path = Path(args.compare_with)
            rd_facts = service.extract(
                rd_path, file_id=document_file_id(rd_path), stage="RD", sheet_no=None,
            )
            comparison = {
                "rd_facts": [asdict(item) for item in rd_facts],
                "findings": [asdict(item) for item in compare_ov_configurations(facts, rd_facts)],
            }
    except AnnotationInputError as error:
        parser.error(str(error))
    _write_json(facts, args.output, llm_audit=audit, comparison=comparison)
