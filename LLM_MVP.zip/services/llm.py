"""OpenAI-compatible LLM adapter stub.

It is intentionally not connected to evidence-producing extraction: an LLM response
without a source bbox must not become an ExtractedFact.
"""
from __future__ import annotations

import json
import os
import urllib.request
from dataclasses import dataclass
from typing import Any, Protocol


class LLMClient(Protocol):
    def complete_json(self, *, system_prompt: str, user_prompt: str) -> dict[str, Any]: ...


class LLMNotConfigured(RuntimeError):
    pass


@dataclass(frozen=True)
class OpenAILikeConfig:
    base_url: str
    model: str
    api_key: str | None = None
    timeout_seconds: float = 30.0

    @classmethod
    def from_env(cls) -> "OpenAILikeConfig":
        base_url = os.getenv("LLM_BASE_URL", "").rstrip("/")
        model = os.getenv("LLM_MODEL", "")
        if not base_url or not model:
            raise LLMNotConfigured("Set LLM_BASE_URL and LLM_MODEL to enable the LLM adapter")
        return cls(base_url, model, os.getenv("LLM_API_KEY"))


class OpenAILikeClient:
    """Minimal `/chat/completions` client for OpenAI-compatible endpoints."""

    def __init__(self, config: OpenAILikeConfig):
        self.config = config

    def complete_json(self, *, system_prompt: str, user_prompt: str) -> dict[str, Any]:
        payload = {
            "model": self.config.model,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        }
        headers = {"Content-Type": "application/json"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        request = urllib.request.Request(
            f"{self.config.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST",
        )
        with urllib.request.urlopen(request, timeout=self.config.timeout_seconds) as response:
            body = json.loads(response.read().decode("utf-8"))
        content = body["choices"][0]["message"]["content"]
        return json.loads(content)
