from __future__ import annotations

from domain.entities import ExtractedFact
from .parameter_compare import ComparisonFinding


def compare_ov_configurations(
    pd_facts: list[ExtractedFact], rd_facts: list[ExtractedFact],
) -> list[ComparisonFinding]:
    """Flag changed HVAC-system sets by room without changing the source facts."""
    rd_by_room = {fact.room: fact for fact in rd_facts}
    findings: list[ComparisonFinding] = []
    for pd_fact in pd_facts:
        rd_fact = rd_by_room.get(pd_fact.room)
        expected = pd_fact.value_norm["items"]
        actual = rd_fact.value_norm["items"] if rd_fact else []
        if expected == actual:
            continue
        findings.append(ComparisonFinding(
            finding_id=f"OV:{pd_fact.room}:systems",
            object_id=pd_fact.room,
            matrix_code="OV-SYSTEMS",
            status="CANDIDATE",
            expected=expected,
            actual=actual,
            evidence=[*pd_fact.evidence, *(rd_fact.evidence if rd_fact else [])],
        ))
    return findings
