# Результаты тестов исправленной версии

Дата прогона: 2026-09-21.

## Unit-тесты

```text
test_annotation_document_is_rejected ... ok
test_bbox_is_normalized_for_rotated_page ... ok
test_binding_does_not_cross_pages ... ok
test_fact_has_per_item_source_evidence ... ok
test_range_uses_natural_order ... ok

Ran 5 tests
OK
```

Проверяются:

- запрет файла предметной разметки как входа;
- нормализация bbox для повёрнутой страницы;
- отсутствие привязки между разными страницами;
- отдельное evidence для каждого элемента множества;
- разворачивание `В2.8-В2.10` и естественная сортировка.

## Проверка на приложенном PDF разметки

```text
error: Annotation/gold PDF rejected (marker: 'состав комплекта').
Use only original PD or RD drawings as extractor input.
```

Это ожидаемый успешный результат защитной проверки. Никакие метрики точности по gold-файлу
не вычислялись, `missing/added` из него не создавались.

## Непроверенное

Автоматическое извлечение 140/142, 147/198 и 314 не заявляется. Для проверки нужны исходные
PDF ПД `АНО/150321/1-П-ИОС5.4.2`, РД `ОВ1` и `ОВ2.1`.
