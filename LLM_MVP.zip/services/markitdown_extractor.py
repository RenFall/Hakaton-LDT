from __future__ import annotations

import hashlib
import re
from pathlib import Path

from markitdown import MarkItDown

from domain.system_rules import OV_TARGET_ROOMS, SYSTEM_RANGE_RE, SYSTEM_RE
from .evidence_locator import EvidenceLocator

ANNOTATION_MARKERS = (
    "комплект предметной разметки",
    "нарушение 3. помещения",
    "состав комплекта",
)


class AnnotationInputError(ValueError):
    pass


def document_file_id(path: Path) -> str:
    digest = hashlib.sha256(path.read_bytes()).hexdigest()[:16]
    return f"sha256:{digest}"


def reject_annotation_text(text: str) -> None:
    lowered = text.lower()
    marker = next((item for item in ANNOTATION_MARKERS if item in lowered), None)
    if marker:
        raise AnnotationInputError(
            f"Annotation/gold PDF rejected (marker: {marker!r}). "
            "Use only original PD or RD drawings as extractor input."
        )


def system_expressions(text: str) -> list[str]:
    range_matches = list(SYSTEM_RANGE_RE.finditer(text))
    expressions = [match.group(0) for match in range_matches]
    range_spans = [match.span() for match in range_matches]
    for match in SYSTEM_RE.finditer(text):
        if not any(start <= match.start() and match.end() <= end for start, end in range_spans):
            expressions.append(match.group(0))
    return list(dict.fromkeys(expressions))


def room_expressions(text: str) -> list[str]:
    """Return only target room numbers that MarkItDown actually found."""
    return sorted(
        (room for room in OV_TARGET_ROOMS if re.search(rf"(?<!\d){room}(?!\d)", text)),
        key=int,
    )


class MarkItDownDrawingExtractor:
    """Primary semantic extractor; bbox lookup is delegated to an EvidenceLocator."""

    def __init__(self, locator: EvidenceLocator, converter: MarkItDown | None = None):
        self.locator = locator
        self.converter = converter or MarkItDown()

    def extract_tokens(self, pdf: str | Path):
        path = Path(pdf)
        text = self.converter.convert(str(path)).text_content
        reject_annotation_text(text)
        return self.locator.locate(path, room_expressions(text), system_expressions(text))
