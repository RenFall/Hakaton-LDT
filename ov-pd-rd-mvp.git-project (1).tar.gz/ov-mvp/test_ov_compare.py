import unittest

import fitz

from ov_compare import (
    AnnotationInputError,
    Token,
    bind_systems_to_rooms,
    build_facts,
    expand_system_expression,
    reject_annotation_pdf,
    normalize_bbox,
    system_sort_key,
)


class OvCompareTests(unittest.TestCase):
    def test_bbox_is_normalized_for_rotated_page(self):
        document = fitz.open()
        page = document.new_page(width=200, height=100)
        page.set_rotation(90)
        bbox = normalize_bbox(page, fitz.Rect(20, 10, 40, 30))
        self.assertTrue(all(0 <= value <= 1 for value in bbox))
        self.assertLess(bbox[0], bbox[2])
        self.assertLess(bbox[1], bbox[3])

    def test_annotation_document_is_rejected(self):
        class FakePage:
            @staticmethod
            def get_text(_kind):
                return "Состав комплекта предметной разметки"

        with self.assertRaises(AnnotationInputError):
            reject_annotation_pdf([FakePage()])

    def test_range_uses_natural_order(self):
        systems = expand_system_expression("В2.8-В2.10")
        self.assertEqual(systems, ["В2.8", "В2.9", "В2.10"])
        self.assertEqual(sorted(systems, key=system_sort_key), systems)

    def test_binding_does_not_cross_pages(self):
        rooms = [Token(1, [0, 0, 10, 10], [0, 0, .1, .1], "140", "140", .95, "test")]
        systems = [
            Token(1, [20, 0, 30, 10], [.2, 0, .3, .1], "В2.7", "В2.7-В2.9", .75, "test"),
            Token(2, [20, 0, 30, 10], [.2, 0, .3, .1], "В2.8", "В2.7-В2.9", .75, "test"),
        ]
        bound = bind_systems_to_rooms(rooms, systems, max_distance=50)
        self.assertEqual([item.text for item in bound["140"]], ["В2.7"])

    def test_fact_has_per_item_source_evidence(self):
        tokens = [
            Token(10, [10, 10, 20, 20], [.1, .1, .2, .2], value, "В2.8-В2.10", .75, "test")
            for value in ("В2.8", "В2.9", "В2.10")
        ]
        fact = build_facts({"198": tokens}, file_id="PD-1", stage="PD", sheet_no="10")[0]
        self.assertEqual(fact.value_norm, {"kind": "set", "items": ["В2.8", "В2.9", "В2.10"]})
        self.assertEqual({item["item"] for item in fact.evidence}, {"В2.8", "В2.9", "В2.10"})
        self.assertTrue(all(item["file_id"] == "PD-1" and item["stage"] == "PD" for item in fact.evidence))


if __name__ == "__main__":
    unittest.main()
